\
# easy_sft (minimal)
A minimal, dependency-light Python implementation of an "Easy Dataset for Finetuning" pipeline.

## Features
- Load: `.md`, `.txt` (optional `.pdf` via PyMuPDF, `.docx` via python-docx)
- Chunk: fixed-size or markdown-aware with overlap
- Question generation: dynamic per-chunk based on char density
- Answer generation: JSON with `cot` and `answer` (COT kept)
- Store: versioned JSONL snapshot (hash-based)
- Export: JSONL raw, Alpaca, ShareGPT

## Quickstart
```bash
# 1) Set your OpenAI-compatible provider

# 2) Prepare a markdown
echo '# Title\n\nThis is a demo text about vector databases and chunking.' > docs.md

# 3) Run
python run_pipeline.py \
  --project demo \
  --paths docs.md \
  --chunker md \
  --chars_per_q 240 \
  --q_concurrency 3 \
  --a_concurrency 3
```

Outputs will be in `./out`: one canonical version file + three export formats.


## New (advanced) flags
- `--config rules.yaml`：品質規則（YAML/JSON）
- `--enable_verify --verify_models a,b,c`：單模型或多模型投票驗證
- `--dedup` / `--dedup_qa`：問題／(Q+A) 去重
- `--balanced_export --per_label N`：依 `domain_tags` 平衡輸出
- `--stratified_export --per_cell N`：依 (domain × difficulty) 分層輸出
- `--difficulty heuristic|llm`：難度標註（啟發式或 LLM）
- `--embed_dedup --embed_thresh 0.92`：TF‑IDF 相似偵測（報表用）
- `--report_html ./out/report.html`：產出可讀 HTML 報表
- `--governance rules.yaml`：治理清洗（正規化替換、是否保留 COT、旗標丟棄等）
