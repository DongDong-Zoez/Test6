\
from __future__ import annotations
from typing import List, Dict, Any
import re
from llm_providers import OpenAICompatible

JARGON = set("""
eigenvalue eigenvector backpropagation convolution transformer attention
gradient hessian divergence entropy regularization bayesian prior posterior
mle map likelihood embedding vector database FAISS Milvus Redis IVF PQ OPQ
tokenization perplexity beamsearch logits crossentropy KL Jensen-Shannon
""".split())

def heuristic_label(question: str, answer: str) -> str:
    q = (question or "").strip()
    a = (answer or "").strip()
    score = 0
    # length
    if len(q) > 120: score += 1
    if len(q) > 240: score += 1
    if len(a) > 200: score += 1
    if len(a) > 600: score += 1
    # punctuation & numbers
    if re.search(r"[()\[\]=></*^]", q): score += 1
    if re.search(r"\d{2,}", q): score += 1
    # jargon overlap
    toks = set(re.findall(r"[A-Za-z]+", q.lower()))
    if len(toks & JARGON) >= 2: score += 1
    # overlap (if question terms not in answer, could be harder)
    atoks = set(re.findall(r"[A-Za-z]+", a.lower()))
    if len((toks - atoks)) > 3: score += 1

    if score <= 1: return "easy"
    if score <= 3: return "medium"
    return "hard"

def llm_label(llm: OpenAICompatible, question: str, answer: str) -> str:
    prompt = f"""Rate the difficulty of the QA as easy/medium/hard for SFT.
Q: {question}
A: {answer}
Answer with one word: easy/medium/hard."""
    out = llm.chat([{"role":"user","content":prompt}], temperature=0.0, max_tokens=2)
    lab = out.strip().lower()
    return "medium" if lab not in {"easy","medium","hard"} else lab

def annotate(rows: List[Dict[str, Any]], method: str = "heuristic", llm: OpenAICompatible | None = None) -> List[Dict[str, Any]]:
    out = []
    for r in rows:
        if method == "llm" and llm is not None:
            lab = llm_label(llm, r.get("question",""), r.get("answer",""))
        else:
            lab = heuristic_label(r.get("question",""), r.get("answer",""))
        r = dict(r)
        meta = dict(r.get("meta") or {})
        meta["difficulty"] = lab
        r["meta"] = meta
        out.append(r)
    return out
