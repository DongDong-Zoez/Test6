\
from __future__ import annotations
from typing import List, Dict, Tuple
import math, re, collections

_word = re.compile(r"[A-Za-z0-9\u4e00-\u9fff]+", re.U)

def tokenize(text: str) -> List[str]:
    return [t.lower() for t in _word.findall(text or "")]

def build_tfidf(texts: List[str]) -> Tuple[List[Dict[int,float]], Dict[str,int], List[float]]:
    """
    Pure-python TF-IDF (no sklearn). Returns:
      - vectors: list of {term_id: tfidf}
      - vocab:   {term -> id}
      - norms:   L2 norm per vector
    """
    vocab: Dict[str,int] = {}
    docs_tokens: List[List[str]] = []
    for t in texts:
        toks = tokenize(t)
        docs_tokens.append(toks)
        for tok in toks:
            if tok not in vocab:
                vocab[tok] = len(vocab)
    # DF
    df = [0]*len(vocab)
    for toks in docs_tokens:
        seen = set(toks)
        for tok in seen:
            df[vocab[tok]] += 1
    N = len(texts)
    idf = [0.0]*len(vocab)
    for i, d in enumerate(df):
        idf[i] = math.log((N + 1) / (d + 1)) + 1.0

    # TF-IDF
    vectors: List[Dict[int,float]] = []
    norms: List[float] = []
    for toks in docs_tokens:
        tf = collections.Counter(toks)
        vec: Dict[int,float] = {}
        for tok, cnt in tf.items():
            j = vocab[tok]
            vec[j] = (cnt / max(1, len(toks))) * idf[j]
        # L2 norm
        n2 = math.sqrt(sum(v*v for v in vec.values())) or 1.0
        vectors.append(vec)
        norms.append(n2)
    return vectors, vocab, norms

def cosine(vec_a: Dict[int,float], norm_a: float, vec_b: Dict[int,float], norm_b: float) -> float:
    if not vec_a or not vec_b: return 0.0
    # iterate smaller
    if len(vec_a) > len(vec_b):
        vec_a, vec_b = vec_b, vec_a
        norm_a, norm_b = norm_b, norm_a
    dot = 0.0
    for j, va in vec_a.items():
        vb = vec_b.get(j)
        if vb is not None:
            dot += va * vb
    return dot / (norm_a * norm_b) if norm_a and norm_b else 0.0

def top_similar(texts: List[str], threshold: float = 0.9, max_neighbors: int = 5) -> List[Tuple[int,int,float]]:
    """
    Return pairs (i, j, sim) with i < j and cosine >= threshold, up to max_neighbors per i.
    """
    vecs, vocab, norms = build_tfidf(texts)
    pairs: List[Tuple[int,int,float]] = []
    for i in range(len(texts)):
        taken = 0
        for j in range(i+1, len(texts)):
            sim = cosine(vecs[i], norms[i], vecs[j], norms[j])
            if sim >= threshold:
                pairs.append((i,j,sim))
                taken += 1
                if taken >= max_neighbors:
                    break
    return pairs
