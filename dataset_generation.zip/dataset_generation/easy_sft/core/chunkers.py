\
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Iterable, Tuple
import re, math

@dataclass
class Chunk:
    id: str
    doc_id: str
    text: str
    start_idx: int
    end_idx: int
    meta: Dict[str, Any]

class FixedSizeChunker:
    """Simple, robust fixed-size character chunker with overlap."""
    def __init__(self, chunk_size: int = 1200, overlap: int = 200):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def split(self, doc_id: str, text: str) -> List[Chunk]:
        chunks = []
        n = len(text)
        i = 0
        k = 0
        while i < n:
            j = min(i + self.chunk_size, n)
            chunk_text = text[i:j].strip()
            if chunk_text:
                chunks.append(Chunk(
                    id=f"{doc_id}::chunk_{k}",
                    doc_id=doc_id,
                    text=chunk_text,
                    start_idx=i,
                    end_idx=j,
                    meta={"strategy":"fixed","chunk_size":self.chunk_size,"overlap":self.overlap}
                ))
                k += 1
            if j == n: break
            i = max(j - self.overlap, 0)
        return chunks

class MarkdownAwareChunker:
    """
    Markdown-structure-aware chunker:
    1) split by headings (#, ##, ###)
    2) within each section, further split by length with overlap
    """
    def __init__(self, chunk_size: int = 1200, overlap: int = 200):
        self.chunk_size = chunk_size
        self.overlap = overlap
        self._heading = re.compile(r'^(#{1,6})\s+.*$', re.M)

    def split(self, doc_id: str, text: str) -> List[Chunk]:
        sections = []
        last = 0
        for m in self._heading.finditer(text):
            if m.start() != 0:
                sections.append((last, m.start()))
            last = m.start()
        sections.append((last, len(text)))

        out: List[Chunk] = []
        idx = 0
        for (s, e) in sections:
            seg = text[s:e].strip()
            if not seg: continue
            # inner split by length
            i = 0
            while i < len(seg):
                j = min(i + self.chunk_size, len(seg))
                ct = seg[i:j].strip()
                if ct:
                    out.append(Chunk(
                        id=f"{doc_id}::chunk_{idx}",
                        doc_id=doc_id,
                        text=ct,
                        start_idx=s+i,
                        end_idx=s+j,
                        meta={"strategy":"md","chunk_size":self.chunk_size,"overlap":self.overlap}
                    ))
                    idx += 1
                if j == len(seg): break
                i = max(j - self.overlap, 0)
        return out
