\
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Dict, Any
import json, os, hashlib, time, uuid
from utils import ensure_dir, sha1

@dataclass
class QAItem:
    id: str
    source_doc_id: str
    chunk_id: str
    domain_tags: list[str]
    question: str
    answer: str | None
    cot: str | None
    meta: Dict[str, Any]

class DatasetStore:
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        ensure_dir(self.base_dir)
        ensure_dir(os.path.join(self.base_dir, "versions"))

    def _version_path(self, name: str) -> str:
        return os.path.join(self.base_dir, "versions", f"{name}.jsonl")

    def create_from_generation(self, project: str, items: List[QAItem]) -> str:
        payload = [asdict(x) for x in items]
        # compute version hash
        ver = sha1(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        outpath = self._version_path(f"{project}-{ver[:10]}")
        with open(outpath, "w", encoding="utf-8") as f:
            for row in payload:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        return outpath

    def read(self, version_file: str) -> List[Dict[str, Any]]:
        rows = []
        with open(version_file, "r", encoding="utf-8") as f:
            for line in f:
                rows.append(json.loads(line))
        return rows
