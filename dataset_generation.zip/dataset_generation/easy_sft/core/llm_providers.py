\
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List, Optional
import os, json, http.client, urllib.parse

@dataclass
class OpenAICompatible:
    """
    Minimal OpenAI-compatible client via HTTP.
    Parameters:
      api_key: required
      base_url: e.g. https://api.openai.com/v1 (no trailing slash)
      model: default model name; can be overridden per call
      timeout: seconds
    """
    def __init__(self, api_key: str, base_url: str, model: str, timeout: int = 120):
        import urllib.parse as _up
        if not api_key or not base_url or not model:
            raise ValueError("api_key, base_url, and model are required.")
        self.api_key = api_key
        self.base_url = base_url[:-1] if base_url.endswith("/") else base_url
        self.model = model
        self.timeout = timeout

    def _request(self, method: str, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        import urllib.parse
        parsed = urllib.parse.urlparse(self.base_url)
        conn_cls = http.client.HTTPSConnection if parsed.scheme == "https" else http.client.HTTPConnection
        conn = conn_cls(parsed.netloc, timeout=self.timeout)
        body = json.dumps(payload)
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        url = parsed.path.rstrip("/") + path
        conn.request(method, url, body=body, headers=headers)
        resp = conn.getresponse()
        data = resp.read()
        if resp.status >= 400:
            raise RuntimeError(f"LLM HTTP {resp.status}: {data.decode('utf-8', errors='ignore')}")
        return json.loads(data.decode("utf-8"))

    def chat(self, messages: List[Dict[str, str]], model: Optional[str]=None, **kwargs) -> str:
        payload = {
            "model": model or self.model,
            "messages": messages,
            "temperature": kwargs.get("temperature", 0.2),
            "max_tokens": kwargs.get("max_tokens", 512)
        }
        out = self._request("POST", "/chat/completions", payload)
        return out["choices"][0]["message"]["content"]
