\
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Iterable
import os, re

@dataclass
class Document:
    id: str
    path: str
    text: str
    meta: Dict[str, Any]

class BaseLoader:
    def load(self, path: str) -> Document:
        raise NotImplementedError

class MarkdownLoader(BaseLoader):
    def load(self, path: str) -> Document:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        return Document(id=os.path.basename(path), path=path, text=text, meta={"type":"markdown"})

class TXTLoader(BaseLoader):
    def load(self, path: str) -> Document:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        return Document(id=os.path.basename(path), path=path, text=text, meta={"type":"txt"})

class PDFLoader(BaseLoader):
    def load(self, path: str) -> Document:
        try:
            import fitz  # PyMuPDF
        except Exception as e:
            raise RuntimeError("PyMuPDF not installed; cannot load PDF") from e
        doc = fitz.open(path)
        texts = []
        for page in doc:
            texts.append(page.get_text("text"))
        text = "\n".join(texts)
        return Document(id=os.path.basename(path), path=path, text=text, meta={"type":"pdf", "pages":len(doc)})

class DocxLoader(BaseLoader):
    def load(self, path: str) -> Document:
        try:
            import docx
        except Exception as e:
            raise RuntimeError("python-docx not installed; cannot load DOCX") from e
        d = docx.Document(path)
        text = "\n".join([p.text for p in d.paragraphs])
        return Document(id=os.path.basename(path), path=path, text=text, meta={"type":"docx"})

def load_texts(paths: Iterable[str]) -> List[Document]:
    loaded = []
    for p in paths:
        ext = os.path.splitext(p)[-1].lower()
        if ext in [".md", ".markdown"]:
            loader = MarkdownLoader()
        elif ext in [".txt"]:
            loader = TXTLoader()
        elif ext in [".pdf"]:
            loader = PDFLoader()
        elif ext in [".docx"]:
            loader = DocxLoader()
        else:
            # fallback to raw read
            loader = TXTLoader()
        loaded.append(loader.load(p))
    return loaded
