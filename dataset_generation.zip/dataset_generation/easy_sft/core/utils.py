\
import hashlib, json, os, re, time, uuid
from dataclasses import dataclass
from typing import Dict, Any, Iterable, List

def sha1(data: str) -> str:
    h = hashlib.sha1()
    h.update(data.encode("utf-8"))
    return h.hexdigest()

def now_iso() -> str:
    import datetime as _dt
    return _dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def ensure_dir(path: str) -> None:
    import os
    os.makedirs(path, exist_ok=True)

@dataclass
class Sample:
    id: str
    source_doc_id: str
    chunk_id: str
    domain_tags: List[str]
    question: str
    answer: str | None = None
    cot: str | None = None
    meta: Dict[str, Any] = None
