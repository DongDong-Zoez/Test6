# Vector DB

This section explains embeddings, top-k retrieval, and chunk overlap.

## Milvus
An open-source vector database.

## Redis
Can store vectors with modules.
