\
from __future__ import annotations
from typing import List, Dict, Any, Iterable
import json

def export_jsonl(rows: List[Dict[str, Any]], path: str) -> str:
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return path

def export_alpaca(rows: List[Dict[str, Any]], path: str) -> str:
    """Map to Alpaca format: instruction,input,output"""
    out = []
    for r in rows:
        out.append({
            "instruction": r["question"],
            "input": r.get("meta", {}).get("context", ""),
            "output": r.get("answer","")
        })
    with open(path, "w", encoding="utf-8") as f:
        for r in out:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return path

def export_sharegpt(rows: List[Dict[str, Any]], path: str) -> str:
    """Very lightweight ShareGPT-ish turns"""
    out = []
    for r in rows:
        out.append({
            "conversations": [
                {"from":"human", "value": r["question"]},
                {"from":"gpt", "value": r.get("answer","")}
            ],
            "meta": {"source_doc_id": r["source_doc_id"], "chunk_id": r["chunk_id"]}
        })
    with open(path, "w", encoding="utf-8") as f:
        for r in out:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return path


from collections import defaultdict
import random

def export_balanced(rows: List[Dict[str, Any]], path: str, label_key: str = "domain_tags", per_label: int = 100, seed: int = 42) -> str:
    """
    Balanced sampling by label_key (supports list labels; each label treated independently).
    Samples up to 'per_label' items for each label.
    """
    random.seed(seed)
    by_label = defaultdict(list)
    for r in rows:
        labels = r.get(label_key, []) or []
        if isinstance(labels, str):
            labels = [labels]
        for lb in labels:
            by_label[lb].append(r)

    sampled = []
    seen_ids = set()
    for lb, items in by_label.items():
        random.shuffle(items)
        take = items[:per_label]
        for it in take:
            if it["id"] not in seen_ids:
                sampled.append(it)
                seen_ids.add(it["id"])

    # write
    with open(path, "w", encoding="utf-8") as f:
        for r in sampled:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return path

\
from __future__ import annotations
from typing import List, Dict, Any
from collections import defaultdict
import json, random

def export_stratified(rows: List[Dict[str,Any]], path: str, label_key: str = "domain_tags", difficulty_key: str = "meta.difficulty", per_cell: int = 50, seed: int = 42) -> str:
    """
    Stratified sampling across (domain_tag x difficulty), up to per_cell each cell.
    difficulty_key supports dotted path "meta.difficulty".
    """
    random.seed(seed)
    def get_difficulty(r):
        cur = r
        for part in difficulty_key.split("."):
            cur = cur.get(part, {}) if isinstance(cur, dict) else {}
        return cur if isinstance(cur, str) else "unknown"

    cells = defaultdict(list)
    for r in rows:
        tags = r.get(label_key, []) or []
        if isinstance(tags, str): tags = [tags]
        diff = get_difficulty(r)
        for t in tags:
            cells[(t, diff)].append(r)

    sampled, seen = [], set()
    for (tag, diff), items in cells.items():
        random.shuffle(items)
        take = items[:per_cell]
        for it in take:
            if it["id"] not in seen:
                sampled.append(it)
                seen.add(it["id"])

    with open(path, "w", encoding="utf-8") as f:
        for r in sampled:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return path

