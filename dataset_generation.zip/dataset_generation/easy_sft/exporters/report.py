\
from __future__ import annotations
from typing import List, Dict, Any, Tuple
import html, json, os
from collections import Counter, defaultdict
from embeddings import top_similar

CSS = """
body { font-family: system-ui, -apple-system, sans-serif; margin: 24px; }
summary { cursor: pointer; }
table { border-collapse: collapse; width: 100%; margin: 12px 0; }
th, td { border: 1px solid #ddd; padding: 8px; vertical-align: top; }
th { background: #f5f5f5; }
.bad { color: #b00020; font-weight: 600; }
.tag { display:inline-block; padding:2px 8px; margin:2px; background:#eef; border-radius:8px; font-size:12px; }
.small { color:#666; font-size:12px; }
"""

def _esc(s: str) -> str:
    return html.escape(str(s or ""))

def write_html_report(rows: List[Dict[str,Any]], quality_report: Dict[str,Any], path: str, sim_threshold: float = 0.9):
    # stats
    n = len(rows)
    by_domain = Counter()
    by_diff = Counter()
    for r in rows:
        tags = r.get("domain_tags") or []
        if isinstance(tags, str): tags = [tags]
        for t in tags:
            by_domain[t] += 1
        diff = (r.get("meta",{}).get("difficulty") or "unknown")
        by_diff[diff] += 1

    # similar questions
    texts = [r.get("question","") for r in rows]
    sim_pairs = top_similar(texts, threshold=sim_threshold, max_neighbors=3)

    html_parts = [f"<style>{CSS}</style>", f"<h1>Easy SFT Report</h1>", f"<p class='small'>Total items: {n}</p>"]

    # Quality section
    html_parts.append("<h2>Quality Report</h2>")
    html_parts.append("<pre>" + _esc(json.dumps(quality_report, ensure_ascii=False, indent=2)) + "</pre>")

    # Domain distribution
    html_parts.append("<h2>Domain Distribution</h2><table><tr><th>Domain</th><th>Count</th></tr>")
    for k, v in by_domain.most_common():
        html_parts.append(f"<tr><td>{_esc(k)}</td><td>{v}</td></tr>")
    html_parts.append("</table>")

    # Difficulty distribution
    html_parts.append("<h2>Difficulty</h2><table><tr><th>Level</th><th>Count</th></tr>")
    for k in ["easy","medium","hard","unknown"]:
        if k in by_diff:
            html_parts.append(f"<tr><td>{_esc(k)}</td><td>{by_diff[k]}</td></tr>")
    html_parts.append("</table>")

    # Similar questions
    html_parts.append("<h2>Potential Duplicates (Question Similarity)</h2>")
    if not sim_pairs:
        html_parts.append("<p>No pairs above threshold.</p>")
    else:
        html_parts.append("<table><tr><th>#</th><th>Q1</th><th>Q2</th><th>Cosine</th></tr>")
        for idx, (i, j, sim) in enumerate(sim_pairs, 1):
            html_parts.append(f"<tr><td>{idx}</td><td>{_esc(texts[i])}</td><td>{_esc(texts[j])}</td><td>{sim:.3f}</td></tr>")
        html_parts.append("</table>")

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(html_parts))
    return path
