\
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Iterable, Tuple
import asyncio
from llm_providers import OpenAICompatible

A_PROMPT = """You answer strictly from the provided chunk. Show your chain-of-thought briefly, then the final concise answer.
Return JSON with keys: "cot", "answer".
If the question cannot be answered from the chunk, set "answer" to "INSUFFICIENT_INFORMATION" and explain in "cot".

Chunk:
<<<
{chunk}
>>>

Question: {q}
JSON:
"""

@dataclass
class AnswerGenerator:
    llm: OpenAICompatible
    concurrency: int = 5
    temperature: float = 0.1

    async def _gen_for_qa(self, chunk_text: str, q: str) -> Dict[str, str]:
        msg = [{"role":"user","content": A_PROMPT.format(chunk=chunk_text, q=q)}]
        out = self.llm.chat(msg, temperature=self.temperature, max_tokens=800)
        import json
        try:
            js = json.loads(out)
            cot = js.get("cot","").strip()
            ans = js.get("answer","").strip()
            return {"cot": cot, "answer": ans}
        except Exception:
            # naive fallback: split last line as answer
            lines = [l.strip() for l in out.splitlines() if l.strip()]
            cot = "\n".join(lines[:-1]) if len(lines) > 1 else out
            ans = lines[-1] if lines else ""
            return {"cot": cot, "answer": ans}

    async def generate(self, chunk_map: Dict[str, Dict[str, Any]], q_map: Dict[str, List[str]]) -> Dict[str, List[Dict[str,str]]]:
        sem = asyncio.Semaphore(self.concurrency)
        results: Dict[str, List[Dict[str,str]]] = {}

        async def worker(cid: str, text: str, questions: List[str]):
            async with sem:
                outs = []
                for q in questions:
                    outs.append(await self._gen_for_qa(text, q))
                results[cid] = outs

        await asyncio.gather(*[worker(cid, chunk_map[cid]["text"], qs) for cid, qs in q_map.items()])
        return results
