\
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Iterable, Tuple
import math, asyncio, re
from llm_providers import OpenAICompatible

Q_PROMPT = """You are a domain expert. Given a knowledge chunk, write N diverse, exam-quality questions that can be answered purely from the chunk.
- Avoid yes/no unless necessary.
- Vary difficulty (basic→advanced), encourage real-world phrasing.
- Output as JSON array of strings only.

Chunk:
<<<
{chunk}
>>>

N = {n}
JSON:
"""

def estimate_question_count(text: str, chars_per_q: int = 240, min_q: int = 1, max_q: int = 8) -> int:
    n = max(min_q, min(max_q, max(1, len(text) // chars_per_q)))
    return n

@dataclass
class QuestionGenerator:
    llm: OpenAICompatible
    concurrency: int = 5
    chars_per_q: int = 240

    async def _gen_for_chunk(self, chunk_text: str, n: int) -> List[str]:
        msg = [{"role":"user","content": Q_PROMPT.format(chunk=chunk_text, n=n)}]
        out = self.llm.chat(msg)
        # try to parse JSON array
        import json
        try:
            arr = json.loads(out)
            arr = [s.strip() for s in arr if isinstance(s, str) and s.strip()]
            return arr[:n] if len(arr) >= n else arr
        except Exception:
            # fallback: split by lines / numbers
            lines = [l.strip("-* \t") for l in out.splitlines() if l.strip()]
            return lines[:n]

    async def generate(self, chunks: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        sem = asyncio.Semaphore(self.concurrency)
        results: Dict[str, List[str]] = {}

        async def worker(cid: str, text: str):
            async with sem:
                n = estimate_question_count(text, self.chars_per_q)
                qs = await self._gen_for_chunk(text, n=n)
                results[cid] = qs

        await asyncio.gather(*[worker(c["id"], c["text"]) for c in chunks])
        return results
