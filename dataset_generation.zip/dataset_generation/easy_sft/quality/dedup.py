\
from __future__ import annotations
from typing import List, Dict, Any, Tuple
from quality import tokenize, simhash, hamming, jaccard

def dedup_near_questions(rows: List[Dict[str, Any]], simhash_bits: int = 64, hamming_thresh: int = 6, jaccard_thresh: float = 0.92) -> Tuple[List[Dict[str,Any]], List[int]]:
    seen_fp: List[int] = []
    out: List[Dict[str, Any]] = []
    removed: List[int] = []

    for idx, r in enumerate(rows):
        q = r.get("question","")
        toks = tokenize(q)
        fp = simhash(toks, bits=simhash_bits)
        is_dup = False
        for k, prev_fp in enumerate(seen_fp):
            if hamming(fp, prev_fp) <= hamming_thresh:
                prev_q = out[k]["question"]
                if jaccard(toks, tokenize(prev_q)) >= jaccard_thresh:
                    is_dup = True
                    break
        if is_dup:
            removed.append(idx)
        else:
            seen_fp.append(fp)
            out.append(r)
    return out, removed

def dedup_near_qa_pairs(rows: List[Dict[str, Any]], simhash_bits: int = 64, hamming_thresh: int = 8, jaccard_thresh: float = 0.90) -> Tuple[List[Dict[str,Any]], List[int]]:
    """
    Remove near-duplicate QA pairs using SimHash/Jaccard over (question + answer).
    Keep first occurrence.
    """
    seen_fp: List[int] = []
    out: List[Dict[str, Any]] = []
    removed: List[int] = []
    for idx, r in enumerate(rows):
        qa = (r.get("question","") + " || " + (r.get("answer","") or "")).strip()
        toks = tokenize(qa)
        fp = simhash(toks, bits=simhash_bits)
        is_dup = False
        for k, prev_fp in enumerate(seen_fp):
            if hamming(fp, prev_fp) <= hamming_thresh:
                prev_qa = (out[k].get("question","") + " || " + (out[k].get("answer","") or "")).strip()
                if jaccard(toks, tokenize(prev_qa)) >= jaccard_thresh:
                    is_dup = True
                    break
        if is_dup:
            removed.append(idx)
        else:
            seen_fp.append(fp)
            out.append(r)
    return out, removed
