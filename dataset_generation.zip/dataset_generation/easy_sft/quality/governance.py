\
from __future__ import annotations
from typing import List, Dict, Any
import re, json, os
try:
    import yaml
except Exception:
    yaml = None

from quality import score_with_rules
from quality_rules import load_rules

def apply_governance(rows: List[Dict[str,Any]], rules_path: str | None) -> List[Dict[str,Any]]:
    """
    Governance rules (YAML/JSON):
      drop_if_flagged: [ "short_question", "empty_answer", ... ]
      regex_replace:
        - { field: "answer", pattern: "\\s+", repl: " " }
      keep_cot: true|false
      quality: (same as quality_rules; optional override)
    """
    if not rules_path or not os.path.exists(rules_path):
        return rows

    if yaml:
        cfg = yaml.safe_load(open(rules_path,"r",encoding="utf-8"))
    else:
        cfg = json.loads(open(rules_path,"r",encoding="utf-8").read())

    drop_flags = set((cfg.get("drop_if_flagged") or []))
    regex_ops = cfg.get("regex_replace") or []
    keep_cot = bool(cfg.get("keep_cot", True))

    # quality subrules override
    qrules = load_rules(rules_path) if cfg.get("quality") else load_rules(None)

    out = []
    for r in rows:
        q = r.get("question","")
        a = r.get("answer","") or ""
        cot = r.get("cot","") or ""

        qc = score_with_rules(q, a, cot, qrules)
        if drop_flags & set(qc.flags):
            continue  # drop

        # regex transforms
        r2 = dict(r)
        for op in regex_ops:
            field = op.get("field")
            pat = op.get("pattern")
            repl = op.get("repl","")
            if field in r2 and isinstance(r2[field], str) and pat:
                r2[field] = re.sub(pat, repl, r2[field])
        if not keep_cot:
            r2["cot"] = None
        out.append(r2)
    return out
