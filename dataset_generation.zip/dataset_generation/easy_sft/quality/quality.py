\
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List, Tuple
import re

BADWORDS = {"n/a", "none", "null", "i don't know", "不知道", "不清楚"}
INSUFFICIENT = {"INSUFFICIENT_INFORMATION", "insufficient_information"}

def _norm(s: str) -> str:
    s = (s or "").strip()
    s = re.sub(r"\s+", " ", s)
    return s

@dataclass
class QAQuality:
    is_valid: bool
    flags: List[str]
    score: float

def basic_badqa_checks(question: str, answer: str, cot: str | None = None) -> QAQuality:
    """Heuristic checks only (no external model). Return flags & a naive score [0..1]."""
    q = _norm(question)
    a = _norm(answer or "")
    c = _norm(cot or "")

    flags: List[str] = []
    if not q or len(q) < 5:
        flags.append("short_question")
    if not a or len(a) < 2:
        flags.append("empty_answer")
    if a.lower() in BADWORDS:
        flags.append("badword_answer")
    if a in INSUFFICIENT:
        flags.append("insufficient_info")
    if not q.endswith("?") and len(q) < 120:
        # encourage natural interrogatives for SFT-style QA
        flags.append("missing_question_mark")
    if len(a) > 2000:
        flags.append("answer_too_long")
    # penalize trivial echoing of the question in the answer
    if q and a and a.lower().startswith(q[:50].lower()):
        flags.append("answer_echoes_question")

    # naive score: start at 1.0 and subtract per flag
    score = max(0.0, 1.0 - 0.12*len(flags))
    is_valid = score >= 0.5 and ("empty_answer" not in flags)
    return QAQuality(is_valid=is_valid, flags=flags, score=score)

def tokenize(s: str) -> List[str]:
    s = s.lower()
    s = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", " ", s)
    toks = [t for t in s.split() if t]
    return toks

def jaccard(a: List[str], b: List[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb: return 1.0
    if not sa or not sb: return 0.0
    inter = len(sa & sb)
    union = len(sa | sb)
    return inter/union

def simhash(tokens: List[str], bits: int = 64) -> int:
    """Simple simhash over tokens; not cryptographic."""
    import hashlib
    v = [0]*bits
    for t in tokens:
        h = int(hashlib.sha1(t.encode('utf-8')).hexdigest(), 16)
        for i in range(bits):
            v[i] += 1 if (h >> i) & 1 else -1
    fp = 0
    for i, val in enumerate(v):
        if val >= 0: fp |= (1 << i)
    return fp

def hamming(a: int, b: int) -> int:
    x = a ^ b
    # count bits
    c = 0
    while x:
        x &= x-1
        c += 1
    return c


def score_with_rules(question: str, answer: str, cot: str | None, rules: dict) -> QAQuality:
    q = (question or "").strip()
    a = (answer or "").strip()
    c = (cot or "").strip() if cot else ""
    flags = []

    if not q or len(q) < rules.get("min_question_len", 5):
        flags.append("short_question")
    if not a or len(a) < 2:
        flags.append("empty_answer")
    if a.lower() in BADWORDS:
        flags.append("badword_answer")
    if a in INSUFFICIENT:
        flags.append("insufficient_info")
    if not q.endswith("?") and len(q) < 120:
        flags.append("missing_question_mark")
    if len(a) > rules.get("max_answer_len", 2000):
        flags.append("answer_too_long")
    if q and a and a.lower().startswith(q[:50].lower()):
        flags.append("answer_echoes_question")

    # Weighted scoring
    weights = rules.get("weights", {})
    penalty = sum(weights.get(f, 0.1) for f in flags)
    score = max(0.0, 1.0 - penalty)
    is_valid = (score >= rules.get("threshold", 0.5)) and ("empty_answer" not in flags)
    return QAQuality(is_valid=is_valid, flags=flags, score=score)
