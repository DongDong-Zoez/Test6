\
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List
import os, re, json

try:
    import yaml  # optional
except Exception:
    yaml = None

DEFAULT_RULES = {
    "weights": {
        "short_question": 0.15,
        "empty_answer": 0.8,
        "badword_answer": 0.5,
        "insufficient_info": 0.6,
        "missing_question_mark": 0.1,
        "answer_too_long": 0.2,
        "answer_echoes_question": 0.2
    },
    "threshold": 0.5,  # min quality score to keep
    "max_answer_len": 2000,
    "min_question_len": 5
}

def load_rules(path: str | None) -> Dict[str, Any]:
    if not path:
        return DEFAULT_RULES
    if not os.path.exists(path):
        return DEFAULT_RULES
    if yaml is not None:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    else:
        # crude fallback for a very simple JSON-as-YAML scenario
        with open(path, "r", encoding="utf-8") as f:
            data = json.loads(f.read())
    # merge shallowly
    out = DEFAULT_RULES.copy()
    out.update(data or {})
    # ensure weights merged
    w = DEFAULT_RULES["weights"].copy()
    w.update((out.get("weights") or {}))
    out["weights"] = w
    return out
