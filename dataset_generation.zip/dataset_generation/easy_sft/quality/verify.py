\
from __future__ import annotations
from typing import Dict, Any, List
from llm_providers import OpenAICompatible

VERIFY_PROMPT = """You are a strict verifier.
Given a context chunk and a QA pair, decide if the *final answer* is fully supported by the chunk.
Reply with compact JSON: {"label":"supported"|"contradicted"|"insufficient","reason":"..."}

Context:
<<<
{context}
>>>

Q: {q}
A: {a}
JSON:
"""

def verify_with_llm(llm: OpenAICompatible, context: str, question: str, answer: str) -> Dict[str, str]:
    msg = [{"role":"user","content": VERIFY_PROMPT.format(context=context, q=question, a=answer)}]
    out = llm.chat(msg, temperature=0.0, max_tokens=200)
    import json
    try:
        js = json.loads(out)
        lab = js.get("label","insufficient").lower()
        rea = js.get("reason","")
        if lab not in {"supported","contradicted","insufficient"}:
            lab = "insufficient"
        return {"label": lab, "reason": rea}
    except Exception:
        return {"label":"insufficient","reason":"parse_error"}

def verify_with_voting(llms: List[OpenAICompatible], context: str, question: str, answer: str) -> Dict[str, Any]:
    votes = {"supported":0, "contradicted":0, "insufficient":0}
    reasons = []
    for client in llms:
        res = verify_with_llm(client, context, question, answer)
        votes[res["label"]] += 1
        reasons.append(res.get("reason",""))
    # majority decision; tie-breaker: supported > insufficient > contradicted
    order = ["supported","insufficient","contradicted"]
    decision = max(order, key=lambda k: (votes[k], -order.index(k)))
    return {"label": decision, "votes": votes, "reasons": reasons}
