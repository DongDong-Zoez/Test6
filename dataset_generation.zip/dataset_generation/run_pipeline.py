\
"""
End-to-end pipeline runner.

Usage (env):
  export OPENAI_API_KEY=...
  export OPENAI_BASE=https://api.openai.com/v1   # or provider base
  export OPENAI_MODEL=gpt-4o-mini                # or deepseek/siliconcloud/...

CLI:
  python run_pipeline.py \
    --project myproj \
    --paths docs/example.md \
    --chunker md \
    --chars_per_q 240 \
    --q_concurrency 5 \
    --a_concurrency 5

Outputs:
  - ./out/versions/myproj-<hash>.jsonl (canonical store)
  - ./out/exports/*.jsonl (alpaca/sharegpt/raw)
"""
import argparse, os, json, asyncio, re
from easy_sft.core.loaders import load_texts
from easy_sft.core.chunkers import FixedSizeChunker, MarkdownAwareChunker
from easy_sft.core.llm_providers import OpenAICompatible
from easy_sft.gen.qagen import QuestionGenerator
from easy_sft.gen.ansgen import AnswerGenerator
from easy_sft.core.dataset import DatasetStore, QAItem
from easy_sft.exporters.export import export_jsonl, export_alpaca, export_sharegpt, export_balanced, export_stratified
from easy_sft.analysis.difficulty_annotator import annotate
from easy_sft.exporters.report import write_html_report
from easy_sft.analysis.embeddings import top_similar
from easy_sft.quality.governance import apply_governance
, export_stratified
\
# === Quality & Dedup imports ===
from easy_sft.quality.quality import basic_badqa_checks, score_with_rules
from easy_sft.quality.dedup import dedup_near_questions, dedup_near_qa_pairs
try:
    from easy_sft.quality.verify import verify_with_llm
except Exception:
    verify_with_llm = None

from easy_sft.quality.quality_rules import load_rules
from easy_sft.quality.verify import verify_with_voting


def guess_domain_tags(doc_text: str) -> list[str]:
    # toy heuristic: extract top-level markdown headings as tags
    tags = []
    for m in re.finditer(r'^#\s+(.+)$', doc_text, flags=re.M):
        tag = m.group(1).strip()
        if tag:
            tags.append(tag[:32])
    return tags[:3] or ["general"]

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True)
    ap.add_argument("--paths", nargs="+", required=True)
    ap.add_argument("--out_dir", default="./out")
    ap.add_argument("--chunker", choices=["fixed","md"], default="md")
    ap.add_argument("--chunk_size", type=int, default=1200)
    ap.add_argument("--overlap", type=int, default=200)
    ap.add_argument("--chars_per_q", type=int, default=240)
    ap.add_argument("--q_concurrency", type=int, default=5)
    ap.add_argument("--a_concurrency", type=int, default=5)
    ap.add_argument("--api_key", required=True)
    ap.add_argument("--base_url", required=True)
    ap.add_argument("--model", required=True)

    ap.add_argument("--enable_verify", action="store_true", help="Use LLM to verify support/contradiction")
    ap.add_argument("--dedup", action="store_true", help="Enable near-duplicate removal on questions")
    ap.add_argument("--dedup_qa", action="store_true", help="Enable near-duplicate removal on (Q+A) pairs")
    ap.add_argument("--config", type=str, default=None, help="YAML/JSON rules for quality/dedup")
    ap.add_argument("--verify_models", type=str, default=None, help="Comma-separated model names for voting verification (uses same base/key)")
    ap.add_argument("--balanced_export", action="store_true")
    ap.add_argument("--per_label", type=int, default=100)

    ap.add_argument("--difficulty", choices=["heuristic","llm"], default="heuristic")
    ap.add_argument("--embed_dedup", action="store_true", help="Use TF-IDF cosine to find duplicates additionally")
    ap.add_argument("--embed_thresh", type=float, default=0.92)
    ap.add_argument("--report_html", type=str, default=None, help="Write an HTML report to this path")
    ap.add_argument("--stratified_export", action="store_true")
    ap.add_argument("--per_cell", type=int, default=60)
    ap.add_argument("--governance", type=str, default=None, help="Governance YAML/JSON to clean/transform rows before versioning")

    ap.add_argument("--hamming_thresh", type=int, default=6)
    ap.add_argument("--jaccard_thresh", type=float, default=0.92)

    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    # 1) Load documents
    docs = load_texts(args.paths)
    print(f"Loaded {len(docs)} docs")

    # 2) Chunk
    if args.chunker == "fixed":
        chunker = FixedSizeChunker(args.chunk_size, args.overlap)
    else:
        chunker = MarkdownAwareChunker(args.chunk_size, args.overlap)

    all_chunks = []
    chunk_map = {}
    for d in docs:
        chs = chunker.split(d.id, d.text)
        all_chunks.extend([{"id": c.id, "text": c.text, "doc_id": d.id} for c in chs])
        for c in chs:
            chunk_map[c.id] = {"text": c.text, "doc_id": d.id}
    print(f"Generated {len(all_chunks)} chunks")

    # 3) Generate Questions
    llm = OpenAICompatible(api_key=args.api_key, base_url=args.base_url, model=args.model)
    qg = QuestionGenerator(llm, concurrency=args.q_concurrency, chars_per_q=args.chars_per_q)
    q_map = await qg.generate(all_chunks)
    total_q = sum(len(v) for v in q_map.values())
    print(f"Generated {total_q} questions")

    # 4) Generate Answers (+ COT)
    ag = AnswerGenerator(llm, concurrency=args.a_concurrency)
    qa_map = await ag.generate(chunk_map, q_map)
    total_a = sum(len(v) for v in qa_map.values())
    print(f"Generated {total_a} answers")

    # 4.9) Optional de-duplication steps on questions and QA-pairs
    rows_tmp = [{
        "id": f"{cid}::q{idx}",
        "source_doc_id": chunk_map[cid]["doc_id"],
        "chunk_id": cid,
        "domain_tags": guess_domain_tags(chunk_map[cid]["text"]),
        "question": q,
        "answer": qa_map.get(cid, [{}]*len(qs))[idx].get("answer") if idx < len(qa_map.get(cid, [])) else None,
        "cot": qa_map.get(cid, [{}]*len(qs))[idx].get("cot") if idx < len(qa_map.get(cid, [])) else None,
        "meta": {"context": chunk_map[cid]["text"][:1500]}
    } for cid, qs in q_map.items() for idx, q in enumerate(qs)]

    if args.dedup and rows_tmp:
        rows_tmp, removed_q = dedup_near_questions(rows_tmp, hamming_thresh=args.hamming_thresh, jaccard_thresh=args.jaccard_thresh)
        quality_report["dedup_removed_questions"] = len(removed_q)
    else:
        quality_report["dedup_removed_questions"] = 0

    if args.dedup_qa and rows_tmp:
        rows_tmp, removed_qa = dedup_near_qa_pairs(rows_tmp)
        quality_report["dedup_removed_qa_pairs"] = len(removed_qa)
    else:
        quality_report["dedup_removed_qa_pairs"] = 0

    # rebuild items from rows_tmp for subsequent steps
    items = []
    for r in rows_tmp:
        from dataset import QAItem
        items.append(QAItem(
            id=r["id"],
            source_doc_id=r["source_doc_id"],
            chunk_id=r["chunk_id"],
            domain_tags=r["domain_tags"],
            question=r["question"],
            answer=r.get("answer"),
            cot=r.get("cot"),
            meta=r.get("meta",{})
        ))
    # 5) Assemble dataset
    items: list[QAItem] = []
    for cid, qs in q_map.items():
        doc_id = chunk_map[cid]["doc_id"]
        tags = guess_domain_tags(chunk_map[cid]["text"])
        for idx, q in enumerate(qs):
            ans = qa_map.get(cid, [{}]*len(qs))[idx] if idx < len(qa_map.get(cid, [])) else {}
            items.append(QAItem(
                id=f"{cid}::q{idx}",
                source_doc_id=doc_id,
                chunk_id=cid,
                domain_tags=tags,
                question=q,
                answer=ans.get("answer"),
                cot=ans.get("cot"),
                meta={"context": chunk_map[cid]["text"][:1500]}
            ))

    store = DatasetStore(os.path.join(args.out_dir))
    # 5.1) Quality checks (BadQA heuristics) and optional LLM verification
    rules = load_rules(args.config)
    quality_report["rules"] = rules

    filtered_items = []
    for it in items:
        qc = score_with_rules(it.question, it.answer or "", it.cot or "", rules)
        quality_report["total"] += 1
        for f in qc.flags:
            quality_report["badqa_flags"][f] = quality_report["badqa_flags"].get(f, 0) + 1
        if qc.is_valid:
            quality_report["valid"] += 1
            filtered_items.append(it)
        else:
            quality_report["invalid"] += 1

    # Optional: LLM verification (single-model or multi-model voting)
    if args.enable_verify and filtered_items:
        # prepare clients
        clients = []
        if args.verify_models:
            names = [m.strip() for m in args.verify_models.split(",") if m.strip()]
            for m in names:
                from easy_sft.core.llm_providers import OpenAICompatible
                clients.append(OpenAICompatible(api_key=args.api_key, base_url=args.base_url, model=m))
        else:
            clients = [llm]

        new_filtered = []
        for it in filtered_items:
            ctx = it.meta.get("context","")
            if len(clients) == 1:
                res = verify_with_llm(clients[0], ctx, it.question, it.answer or "") if verify_with_llm else {"label":"insufficient"}
                lab = res.get("label","insufficient")
                reason = res.get("reason","")
                quality_report["verified"][lab] = quality_report["verified"].get(lab,0) + 1
                if lab != "contradicted":
                    new_filtered.append(it)
            else:
                res = verify_with_voting(clients, ctx, it.question, it.answer or "")
                lab = res.get("label","insufficient")
                quality_report["verified"][lab] = quality_report["verified"].get(lab,0) + 1
                # keep all except majority-contradicted
                if lab != "contradicted":
                    new_filtered.append(it)
        filtered_items = new_filtered

    quality_report = {"badqa_flags": {}, "total": 0, "valid": 0, "invalid": 0, "verified": {"supported":0,"contradicted":0,"insufficient":0}}
    filtered_items = []
    for it in items:
        qc = basic_badqa_checks(it.question, it.answer or "", it.cot or "")
        quality_report["total"] += 1
        for f in qc.flags:
            quality_report["badqa_flags"][f] = quality_report["badqa_flags"].get(f, 0) + 1
        if qc.is_valid:
            quality_report["valid"] += 1
            filtered_items.append(it)
        else:
            quality_report["invalid"] += 1

    # Optional: LLM verification against the chunk context
    if args.enable_verify and filtered_items:
        _llm = llm
        new_filtered = []
        for it in filtered_items:
            ctx = it.meta.get("context","")
            res = verify_with_llm(_llm, ctx, it.question, it.answer or "") if verify_with_llm else {"label":"insufficient"}
            lab = res.get("label","insufficient")
            if lab in quality_report["verified"]:
                quality_report["verified"][lab] += 1
            # keep all except explicit contradictions
            if lab != "contradicted":
                new_filtered.append(it)
        filtered_items = new_filtered
    else:
        # if not verifying, proceed with heuristic-only filtered items
        pass

    # 5.2) De-dup similar questions
    rows_tmp = [{
        "id": it.id,
        "source_doc_id": it.source_doc_id,
        "chunk_id": it.chunk_id,
        "domain_tags": it.domain_tags,
        "question": it.question,
        "answer": it.answer,
        "cot": it.cot,
        "meta": it.meta
    } for it in filtered_items]

    if args.dedup and rows_tmp:
        rows_tmp, removed_idx = dedup_near_questions(rows_tmp, hamming_thresh=args.hamming_thresh, jaccard_thresh=args.jaccard_thresh)
        quality_report["dedup_removed"] = len(removed_idx)
    else:
        quality_report["dedup_removed"] = 0

    # Overwrite items with filtered/deduped
    items = []
    for r in rows_tmp:
        from dataset import QAItem
        items.append(QAItem(
            id=r["id"],
            source_doc_id=r["source_doc_id"],
            chunk_id=r["chunk_id"],
            domain_tags=r["domain_tags"],
            question=r["question"],
            answer=r.get("answer"),
            cot=r.get("cot"),
            meta=r.get("meta",{})
        ))

    version_file = store.create_from_generation(args.project, items)
    rows = store.read(version_file)
# 5b) Quality Control
from quality import deduplicate, badqa_filter, contradiction_check
rows = deduplicate(rows)
rows = badqa_filter(rows)
rows = contradiction_check(rows)
print(f"After QC: {len(rows)} rows")

    print(f"Stored version at: {version_file} ({len(rows)} rows)")

    # 6) Export
    exp_dir = os.path.join(args.out_dir, "exports")
    os.makedirs(exp_dir, exist_ok=True)
    raw_path = os.path.join(exp_dir, f"{args.project}.jsonl")
    alpaca_path = os.path.join(exp_dir, f"{args.project}.alpaca.jsonl")
    sharegpt_path = os.path.join(exp_dir, f"{args.project}.sharegpt.jsonl")
    export_jsonl(rows, raw_path)
    export_alpaca(rows, alpaca_path)
    export_sharegpt(rows, sharegpt_path)
    print("Exports:")
    print("  RAW     :", raw_path)
    print("  ALPACA  :", alpaca_path)
    print("  SHARGPT :", sharegpt_path)

    # Balanced export (optional)
    if args.balanced_export:
        balanced_path = os.path.join(exp_dir, f"{args.project}.balanced.jsonl")
        export_balanced(rows, balanced_path, label_key="domain_tags", per_label=args.per_label)
        print("  BALANCED:", balanced_path)

if __name__ == "__main__":
    asyncio.run(main())

    rows = [dict(r) for r in rows]

    # Difficulty annotate
    rows = annotate(rows, method=args.difficulty, llm=llm if args.difficulty=="llm" else None)

    # Governance cleaning (optional, before exports)
    rows = apply_governance(rows, args.governance)

    # Embedding-based duplicate discovery (report use)
    if args.embed_dedup and rows:
        qs = [r.get("question","") for r in rows]
        # store top similar pairs into quality_report
        from easy_sft.analysis.embeddings import top_similar
        sim_pairs = top_similar(qs, threshold=args.embed_thresh, max_neighbors=3)
        quality_report["embed_similar_pairs"] = [{"i":i,"j":j,"sim":float(s)} for (i,j,s) in sim_pairs]

    # Optional HTML report
    if args.report_html:
        report_path = args.report_html
        try:
            from easy_sft.exporters.report import write_html_report
            write_html_report(rows, quality_report, report_path, sim_threshold=args.embed_thresh)
            print("  REPORT  :", report_path)
        except Exception as e:
            print("Report generation failed:", e)
    rows = store.read(version_file)
    print(f"Stored version at: {version_file} ({len(rows)} rows)")

    # 6) Export